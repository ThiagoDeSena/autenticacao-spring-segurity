package br.com.projeto;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class CodificaApplicationTests {

	@Test
	void contextLoads() {
	}

}
