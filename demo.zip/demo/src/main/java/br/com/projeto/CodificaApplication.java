package br.com.projeto;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class CodificaApplication {

	public static void main(String[] args) {
		SpringApplication.run(CodificaApplication.class, args);
	}

}
